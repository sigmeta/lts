username = 'xuta'
# username = 'v-reyi'
login_user = 'xuta'
password = 'Bepositive&movefast'
local_ssh = 'xutan@10.150.144.98'

project_name = 'transformer/lts'
remote_project_name = 'transformer/lts'

pai_ip = '10.150.144.95'
pai_port = '4717'
pai_token = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VybmFtZSI6InJlbnlpIiwiYWRtaW4iOmZhbHNlLCJpYXQiOjE1MzY4MjYwNzMsImV4cCI6MTUzNjkxMjQ3M30.glvcb2MyRia_ISSyFJ5KHF5jFmCcld6pv8MoOlUd-K4'

if __name__ == "__main__":
    print(
        "export user_name={} project_name={} remote_project_name={}".format(username, project_name, remote_project_name))
