# Philly Tools

## Install 
```bash
pip install -r philly/requirements.txt
```

## Files need to be modified
- configure_philly.sh
- settings.sh
- rsync_data.txt
- rsync_exclude.txt